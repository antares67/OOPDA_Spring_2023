public class Driver {
    public static void main(String[] args) {
    Simulator mysim = new Simulator(100,100);
    mysim.runLongSimulation();
    }
    }
    